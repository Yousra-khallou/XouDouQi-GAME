package com.XouDouQi.BLL;

import java.util.Scanner;

import org.slf4j.Logger;

import java.time.LocalDateTime;
import com.XouDouQi.BO.*;
import com.XouDouQi.DAL.*;


public class GameManager {
	//pour gerer les transactions concernant les parties du game
	private GamePartDAO Gp = new GamePartDAO();
	//pour gerer les transactions qui concerne les joueurs
	private joueurDAO JoueurDAO = new joueurDAO();
	  public  void afficheMenuGame() {
		  for(int i=0;i<12;i++) {
				 System.out.println(" ");
			 }
	        System.out.println("                =======================================");
	        System.out.println("               ||     🐾 Jungle Animal Chess 🐾        ||");
	        System.out.println("                =======================================");
	        System.out.println(" ");
	        System.out.println(" ");
	        System.out.println("          1. Afficher Mes informations ");
	        System.out.println(" ");
	        System.out.println("          2. Historique de Mes parties");
	        System.out.println(" ");
	        System.out.println("          3. Lancer une nouvelle partie");
	        System.out.println(" ");
	        System.out.println("          4. Historique des parties jouées");
	        System.out.println(" ");
	        System.out.println("          5. Se Déconnecter");
	        System.out.println(" ");
	        System.out.print("                           Veuillez entrer votre choix : ");
	    }

	  
	 public void afficherHistorique(joueur j) {
		 for(int i=0;i<10;i++) {
			 System.out.println("                  ");
		 }
		 System.out.println("-----------------------------------------------------------");
		 for(int i=0;i<3;i++) {
			 System.out.println("                  ");
		 }
		 
		 Gp.afficheHistoriqueParJoueur(j.getIdjoueur());
	 }
	 
	 
	public void afficherHistoriqueParties() {
		for(int i=0;i<13;i++) {
			 System.out.println(" ");
		 }
		 System.out.println("---------------------------------------------------");
		 for(int i=0;i<3;i++) {
			 System.out.println("                  ");
		 }
		Gp.afficheHistorique();
	}
	
	
	
	public void afficherInfosJoueur(joueur j) {
	    final String RESET = "\u001B[0m";
	    final String BLUE = "\u001B[34m";
	    final String GREEN = "\u001B[32m";
	    final String CYAN = "\u001B[36m";
	    final String YELLOW = "\u001B[33m";

	    for (int i = 0; i < 5; i++) {
	        System.out.println();
	    }
     
	    System.out.println(CYAN + "-----------------------------------------------" + RESET);
	    System.out.println("                  ");
	    System.out.printf("| %s%-30s%s : %s%-10s%s |\n", BLUE, "Identifiant", RESET, GREEN, j.getIdjoueur(), RESET);
	    System.out.println("                  ");
	    System.out.printf("| %s%-30s%s : %s%-10s%s |\n", BLUE, "UserName", RESET, GREEN, j.getUsername(), RESET);
	    System.out.println("                  ");
	    System.out.printf("| %s%-30s%s : %s%-10d%s |\n", BLUE, "Total Victories", RESET, YELLOW, j.getTotal_victories(), RESET);
	    System.out.println("                  ");
	    System.out.printf("| %s%-30s%s : %s%-10d%s |\n", BLUE, "Score", RESET, YELLOW, j.getScore(), RESET);
	    System.out.println("                  ");
	    System.out.println(CYAN + "-----------------------------------------------" + RESET);
	    for(int i=0;i<7;i++) {
			 System.out.println(" ");
		 }
	}


	
	
	public void lancerNouvellePartie(joueur j1, Scanner sc,Logger logger) throws GameManagerExeption {
		
		try {
	        // Choix de l'adversaire
	        System.out.print(" Entrez l'ID de l'adversaire : ");
	        int idAdv = sc.nextInt();
	        joueur adversaire = JoueurDAO.connexionJoueurById(idAdv);

	        if (adversaire == null) {
	            System.out.println(" Aucun joueur trouvé avec cet ID.");
	            try {
				    Thread.sleep(3000);  // Pause 3 secondes
				} catch (InterruptedException e) {
				    e.printStackTrace();
				}
	            afficheMenuGame();
	            return;
	        }

	        if (adversaire.getIdjoueur() == j1.getIdjoueur()) {
	            System.out.println("! Vous ne pouvez pas jouer contre vous-même !");
	            try {
				    Thread.sleep(3000);  // Pause 3 secondes
				} catch (InterruptedException e) {
				    e.printStackTrace();
				}
	            afficheMenuGame();
	            return;
	        }

	        System.out.println("\n Début de la partie entre " + j1.getUsername() + " et " + adversaire.getUsername());
	        System.out.println("                  ");
	        System.out.println("Les pièces de "+j1.getUsername()+" Rat 🐀 Chat 🐱 Chien 🐶 Loup  🐺  Panthère 🐆  Tigre 🐯  Lion 🦁  Éléphant 🐘");
	        System.out.println("                  ");
	        System.out.println("Les pièces de "+adversaire.getUsername()+" Rat R Chat C Chien D Loup  W  Panthère P   Tigre T  Lion L  Éléphant E");
	        try {
			    Thread.sleep(5000);  // Pause 3 secondes
			} catch (InterruptedException e) {
			    e.printStackTrace();
			}
	        lancerPartie(j1, adversaire,logger);
	        
	        
		} catch (DbException e) {
	        System.out.println("Erreur base de données : " + e.getMessage());
	    }
	

	}
	
	    public  void lancerPartie(joueur j1, joueur j2,Logger logger) {
	        Scanner sc = new Scanner(System.in);
	        Echiquier echiquier = new Echiquier(j1, j2);

	        boolean partieEnCours = true;
	        joueur joueurActif = j1;

	        while (partieEnCours) {
	            System.out.println("\n\n=================== Tour de " + joueurActif.getUsername() + " =================");
	            echiquier.afficheEchiquier(j1, j2);

	            System.out.print("Entrez les coordonnées de la pièce à déplacer (x y) : ");
	            int x1 = sc.nextInt();
	            int y1 = sc.nextInt();
	            position posDepart = new position(x1, y1);
	            animal a = echiquier.getAnimal(posDepart);

	            if (a == null || !a.getPropriétaire().equals(joueurActif)) {
	                System.out.println("Aucune pièce à vous à cette position. Réessayez.");
	                continue;
	            }

	            System.out.print("Entrez les coordonnées de destination (x y) : ");
	            int x2 = sc.nextInt();
	            int y2 = sc.nextInt();
	            position posDest = new position(x2, y2);
               //move si possible et updater le score
	            a.Move(echiquier, posDest);
	            
	         // Vérifier victoire par élimination de tous les pieces adverses 
	            
	            joueur adversaire = joueurActif.equals(j1) ? j2 : j1;
	            if (!echiquier.aDesPiecesActive(adversaire) || echiquier.estSanctuaireAdverse(posDest, joueurActif)) {
	            	if (!echiquier.aDesPiecesActive(adversaire))
	            	{
	            	System.out.println("\n                  💥 Tous les animaux de " + adversaire.getUsername() + " ont été capturés !");
	                System.out.println("");
	                }
	            	else {
	            		System.out.println("\n         🎉🎉  " + joueurActif.getUsername() + " a gagné en atteignant le sanctuaire adverse ! 🎉🎉\n");
	            	}
	            	System.out.println("");
	            	System.out.println("");
	                System.out.println("                       🎉🎉 " + joueurActif.getUsername() + " remporte la victoire ! 🎉🎉");
	                try {
					    Thread.sleep(5000);  // Pause 5 secondes
					} catch (InterruptedException e) {
					    e.printStackTrace();
					}
	                
	                //augmenter le nombre du vectoires associe au joeur gagnat
	                joueurActif.setTotal_victories(joueurActif.getTotal_victories()+1);
	                
	                // apres l'enregistrer dans la base de donnees
	                JoueurDAO.updateVictories(joueurActif.getIdjoueur(),joueurActif.getTotal_victories());
	                
	                System.out.println("Mise A Jour des informations du gagnat Apres La Partie: ");
	                afficherInfosJoueur(joueurActif);
	                
	                joueur gagnant = joueurActif;
	                try {
	                    boolean updated1 = JoueurDAO.updateScore(gagnant.getIdjoueur(), gagnant.getScore());
	                    boolean updated2= JoueurDAO.updateVictories(joueurActif.getIdjoueur(),joueurActif.getTotal_victories());
	                    if (updated1 & updated2) {
	                    	logger.info("✅ Score mis à jour pour " + gagnant.getUsername() + " : " + gagnant.getScore());

	                        
	                    } else {
	                    	logger.info("Échec de la mise à jour du score");
	                        
	                    }
	                } catch (DbException e) {
	                	logger.info(" Erreur lors de la mise à jour du score : " + e.getMessage());
	                   
	                }
	                GamePart partie = new GamePart(j1.getIdjoueur(), j2.getIdjoueur(), gagnant.getIdjoueur(), j1.getScore() + j2.getScore(), LocalDateTime.now());

	                try {
	                	Gp.SauvegarderPart(partie);
	                	logger.info("Partie sauvegardée avec succès");
	                    
	                } catch (DbException e) {
	                	logger.info("Erreur lors de la sauvegarde de la partie : " + e.getMessage());
	                    
	                }
	                partieEnCours = false;
	                continue;
	            }

	      
	            // Passer au joueur suivant
	            joueurActif = joueurActif.equals(j1) ? j2 : j1;
	        }
	    }
	} 

