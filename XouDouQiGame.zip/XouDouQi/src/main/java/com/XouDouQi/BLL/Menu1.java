package com.XouDouQi.BLL;

public class Menu1 {

    public static void afficheMenuPrincipal() {
    	
    	for (int i = 0; i < 17; i++) {
            System.out.println();
        }
        System.out.println("                               +++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("                              |          🦁 ANIMAL   🐯                           |");
        System.out.println("                              |              🏰         CHESS   🐯                |");
        System.out.println("                               +++++++++++++++++++++++++++++++++++++++++++++++++++");

        // Espaces pour l'esthétique
        for (int i = 0; i < 3; i++) {
            System.out.println();
        }

        System.out.println("                1 -  Règles du jeu");
        System.out.println("                2 -  Connexion");
        System.out.println("                3 -  Créer un compte");
        System.out.println("                4 -  Quitter");
        System.out.println();
        System.out.print("         Veuillez entrer votre choix : ");
    }
    
   
  
}
