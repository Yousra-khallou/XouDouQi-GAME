package com.XouDouQi.BLL;

public class GameManagerExeption extends  Exception{
	

	    public GameManagerExeption() {
	    }
	    public GameManagerExeption(String message) {
	        super(message);
	    }

	    public GameManagerExeption(String message, Throwable cause) {
	        super(message, cause);
	    }
	}


