package com.XouDouQi.BLL;
import java.util.Scanner;

import com.XouDouQi.BO.joueur;
import com.XouDouQi.DAL.DbException;
import com.XouDouQi.DAL.joueurDAO;

public class LogInJoueur {
	
	    public static joueur connexion(Scanner sc) {
	        
				System.out.println("                    ==========  Connexion Joueur ==========");
       			System.out.println(" ");
				System.out.print("ID joueur : ");
				int id = sc.nextInt();
				sc.nextLine(); 
				System.out.println("   ");
				System.out.print("Nom d'utilisateur : ");
				String username = sc.nextLine();

				try {
				    joueurDAO dao = new joueurDAO();
				    joueur j = dao.connexionJoueur(id, username);

				    if (j != null) {
				    	System.out.println("-----------------------------------------------------");
				    	System.out.println(" ");
				        System.out.println("    Connexion réussie. Bienvenue, " + j.getUsername() + " !");
				        return j;
				    } else {
				        System.out.println(" Échec de connexion : ID ou nom incorrect.");
				        
				        return null;
				    }

				} catch (DbException ex) {
				    System.out.println(" Erreur de connexion à la base de données.");
				    ex.printStackTrace();
				    return null;
				}
			}
	    
	    
	    

	        public static joueur creerCompte(Scanner sc) {
	               
	                afficherRules.clearConsole();
	                System.out.println("-----------------------------------------------------------------------");
					System.out.println("");
	                System.out.println("==============  Création de compte ============");

					System.out.print("Entrez un nom d'utilisateur : ");
					String username = sc.nextLine().trim();

					if (username.isEmpty()) {
					    System.out.println(" Le nom d'utilisateur ne peut pas être vide.");
					    return null;
					}

					joueur nouveau = new joueur(username); // score et total_victories par défaut = 0

					try {
					    joueurDAO dao = new joueurDAO();
					    boolean created = dao.CreateCompte(nouveau);

					    if (created) {
					        System.out.println("✅ Compte créé avec succès !");
					        System.out.println(" ");
					        System.out.println(" ");
					        System.out.println("          🆔 Votre identifiant est : " + nouveau.getIdjoueur());
					        System.out.println("          Votre UserName est : " + nouveau.getUsername());
					        
					        return nouveau;
					    } else {
					        System.out.println(" Échec de la création du compte.");
					        return null;
					    }

					} catch (DbException e) {
					    System.out.println(" Erreur lors de l'accès à la base de données.");
					    e.printStackTrace();
					    return null;
					}
				}
	        }

	    

	

