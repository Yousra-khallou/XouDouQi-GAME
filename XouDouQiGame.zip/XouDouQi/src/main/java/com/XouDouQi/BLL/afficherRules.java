package com.XouDouQi.BLL;

import java.util.Scanner;

public class afficherRules {
 public static void rules(Scanner sc ) {
	        for(int i=0;i<10;i++) {
		        System.out.println(" ");
	         }

             System.out.println("------------------------------------------------------");
	         System.out.println("RÈGLES DU JEU - Xou Dou Qi (Échecs d'animaux)");
	         System.out.println("--------------------------------------------------");
	         System.out.println("🎯 Objectif :");
	         System.out.println("- Amener l’un de vos animaux dans le sanctuaire adverse (🏰).");
	         System.out.println("- Ou éliminer tous les animaux de l’adversaire.");

	         System.out.println("\nDéroulement du jeu :");
	         System.out.println("- Deux joueurs s’affrontent, chacun contrôle 8 Pieces(animaux).");
	         System.out.println("- À chaque tour, un joueur déplace une de ses pièces.");
	         System.out.println("- Les animaux se déplacent d’une case (↑ ↓ ← →), sauf tigre et lion (peut saut rivière).");

	         System.out.println("\nForces des animaux (de 1 à 8) :");
	         System.out.println("1. Rat 🐀 < 2. Chat 🐱< 3. Chien 🐶 < 4. Loup  🐺 < 5. Panthère 🐆 < 6. Tigre 🐯 < 7. Lion 🦁 < 8. Éléphant 🐘 ");
	        
	         System.out.println("\nRegles de Capture :");
	         System.out.println("- Un animal peut capturer un animal adverse de force égale ou inférieure.");
	         System.out.println("- Rat peut capturer l'éléphant.");
	         System.out.println("- Pièce dans un piège peut être capturée par n’importe qui.");
	         System.out.println("- Deux rats ne peuvent se capturer que s’ils sont sur le même type de terrain.");

	         System.out.println("\n🌊 Rivières :");
	         System.out.println("- Interdites pour tous sauf le rat.");
	         System.out.println("- Le lion et le tigre peuvent les sauter s’il n’y a aucun rat dessus.");

	         System.out.println("\n Sanctuaire :");
	         System.out.println("- Chaque joueur a un sanctuaire (S) protégé par des pièges (*).");
	         System.out.println("- Un joueur gagne en entrant dans le sanctuaire adverse avec un de ses animaux.");

	         System.out.println("\nScore :");
	         System.out.println(" +3 points à chaque capture.");

	         System.out.println("                           \n✅ Bon jeu et que le meilleur stratège gagne !");
	         System.out.println("\nAppuyez sur Entrée pour revenir au menu...");

	         sc.nextLine(); // attend que l'utilisateur appuie sur Entrée
	         
	         clearConsole();
	        

	         
	         
	     }
	     
 
 
 public static void clearConsole() {
	 for(int i=0;i<20;i++) {
		 System.out.println(" ");
	 }
	}

	

 }
  
