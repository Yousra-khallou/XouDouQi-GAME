package com.XouDouQi.DAL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import com.XouDouQi.BO.*;


public class GamePartDAO {	
	private Connection con = DbUtils.getConnection() ;
		
public boolean SauvegarderPart(GamePart G) throws DbException {
			int generatedId = -1;
			try {

				// instruction SQl avec un paramètre
				String InsertReq = "insert into GamePart(idjoueur1,idjoueur2,idgagnat,score) values(?,?,?,?)";
				// créer l'objet PreparedStatement
				PreparedStatement stm = con.prepareStatement(InsertReq, Statement.RETURN_GENERATED_KEYS);
				// définir la valeur du paramètre de la l'instruction SQL
				stm.setInt(1, G.getIdjoueur1());
				stm.setInt(2, G.getIdjoueur2());
				stm.setInt(3, G.getIdgagnant());
				stm.setInt(4, G.getScore());

				
				// Executer l'instruction SQL
				stm.executeUpdate();

				ResultSet generatedKeys = stm.getGeneratedKeys();
				if (generatedKeys.next()) {
					generatedId = generatedKeys.getInt(1);
					G.setIdpartie(generatedId);  
					return true;
				}
				
				return false;
			} catch (SQLException ex) {
				// remonter l'erreur
				throw new DbException(ex);
			}

		}
		// historique de toutes les parties jouees
		public void afficheHistorique() throws DbException {
		    String query = """
		        SELECT gp.idpartie, 
		               j1.username AS joueur1, 
		               j2.username AS joueur2, 
		               g.username AS gagnant,
		               gp.score,
		               gp.datepartie
		        FROM GamePart gp
		        JOIN joueur j1 ON gp.idjoueur1 = j1.idjoueur
		        JOIN joueur j2 ON gp.idjoueur2 = j2.idjoueur
		        LEFT JOIN joueur g ON gp.idgagnat = g.idjoueur
		        ORDER BY gp.datepartie DESC
		        """;

		    try (PreparedStatement stmt = con.prepareStatement(query);
		         ResultSet rs = stmt.executeQuery()) {

		        System.out.printf("%-10s %-15s %-15s %-15s %-10s %-20s%n", 
		                          "IDpartie", "Joueur 1", "Joueur 2", "Gagnant", "Score", "Date de partie");
		        System.out.println("-----------------------------------------------------------------------------");
		        for(int i=0;i<2;i++) {
					 System.out.println(" ");
				 }
		        while (rs.next()) {
		            int idPartie = rs.getInt("idpartie");
		            String joueur1 = rs.getString("joueur1");
		            String joueur2 = rs.getString("joueur2");
		            String gagnant = rs.getString("gagnant"); // peut être null
		            int score = rs.getInt("score");
		            LocalDateTime date = rs.getTimestamp("datepartie").toLocalDateTime();

		            System.out.printf("%-10d %-15s %-15s %-15s %-10d %-20s%n", 
		                              idPartie, joueur1, joueur2, 
		                              (gagnant != null ? gagnant : "Égalité"), 
		                              score, date);
		        }

		    } catch (SQLException e) {
		        throw new DbException(e);
		    }
		}
		//historique pour un joueur specifique
		public void afficheHistoriqueParJoueur(int idJoueur) throws DbException {
		    String query = """
		        SELECT gp.idpartie, 
		               j1.username AS joueur1, 
		               j2.username AS joueur2, 
		               g.username AS gagnant,
		               gp.score,
		               gp.datepartie
		        FROM GamePart gp
		        JOIN joueur j1 ON gp.idjoueur1 = j1.idjoueur
		        JOIN joueur j2 ON gp.idjoueur2 = j2.idjoueur
		        LEFT JOIN joueur g ON gp.idgagnat = g.idjoueur
		        WHERE gp.idjoueur1 = ? OR gp.idjoueur2 = ?
		        ORDER BY gp.datepartie DESC
		        """;

		    try (PreparedStatement stmt = con.prepareStatement(query)) {
		        stmt.setInt(1, idJoueur);
		        stmt.setInt(2, idJoueur);
		        try (ResultSet rs = stmt.executeQuery()) {
		            System.out.printf("%-10s %-15s %-15s %-15s %-10s %-20s%n", 
		                              "IDpartie", "Joueur 1", "Joueur 2", "Gagnant", "Score", "Date de partie");
		            System.out.println("----------------------------------------------------------------------------");
		            for(int i=0;i<2;i++) {
						 System.out.println(" ");
					 }
		            boolean trouvé = false;
		            while (rs.next()) {
		            	trouvé = true;
		                int idPartie = rs.getInt("idpartie");
		                String joueur1 = rs.getString("joueur1");
		                String joueur2 = rs.getString("joueur2");
		                String gagnant = rs.getString("gagnant");
		                int score = rs.getInt("score");
		                LocalDateTime date = rs.getTimestamp("datepartie").toLocalDateTime();

		                System.out.printf("%-10d %-15s %-15s %-15s %-10d %-20s%n", 
		                                  idPartie, joueur1, joueur2, 
		                                  (gagnant != null ? gagnant : "Égalité"), 
		                                  score, date);
		            }

		            if (!trouvé) {
		                System.out.println("\n  !!!!!!! Aucun historique trouvé pour ce joueur.");
		            }
		        }

		    } catch (SQLException e) {
		        throw new DbException(e);
		    }
		}


	}
		
		


