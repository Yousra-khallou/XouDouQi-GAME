package com.XouDouQi.DAL;

@SuppressWarnings("serial")
public class DbException extends RuntimeException {
	

	    public DbException(String message) {
	        super(message);
	    }

	    public DbException(String message, Throwable cause) {
	        super(message, cause);
	    }

	    public DbException(Throwable cause) {
	        super("erreur d'execution d'un ordre SQL", cause);
	    }
	}

