package com.XouDouQi.DAL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;




public class databaseinstaller {

	 public static boolean checkIfDbExist() {
	        try {
	            Connection connection = DbUtils.getConnection();

	            // Vérifier si la table joueur existe
	            String checkTableSQL =
	                    """
	                            SELECT COUNT(*) AS tableCount
	                            FROM INFORMATION_SCHEMA.TABLES
	                            WHERE TABLE_NAME = 'JOUEUR';
	                            """;

	            Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery(checkTableSQL);

	            return resultSet.next() && resultSet.getInt("tableCount") == 1;

	        } catch (Exception ex) {
	            throw new DbException("Erreur de vérification de l'installation", ex);
	        }
	    }
	 
	 
	 public static boolean install() {
	        try {
	            Connection connection = DbUtils.getConnection();
	            Statement statement = connection.createStatement();


	            String createTablejoueur = """
	                    CREATE TABLE IF NOT EXISTS joueur(
	                    idjoueur INT PRIMARY KEY AUTO_INCREMENT,
	                    userName VARCHAR(255) NOT NULL ,
	                    total_victories INT DEFAULT 0,
	                    score INT DEFAULT 0
	                 )""";

	            String createTableParties = """
	                                        CREATE TABLE IF NOT EXISTS GamePart (
	                                        idpartie INT PRIMARY KEY AUTO_INCREMENT,
	                                        idjoueur1 INT NOT NULL,
	                                        idjoueur2 INT NOT NULL,
	                                        idgagnat INT,               
	                                        score INT,
	                                        datepartie DATETIME DEFAULT CURRENT_TIMESTAMP,             
                                            FOREIGN KEY(idjoueur1) REFERENCES joueur(idjoueur),
                                            FOREIGN KEY(idjoueur2) REFERENCES joueur(idjoueur),
                                            FOREIGN KEY(idgagnat) REFERENCES joueur(idjoueur)
	                                )""";


	            statement.execute(createTablejoueur);
	            statement.execute(createTableParties);
	            

	            return true;


	        } catch (Exception ex) {
	            throw new DbException("Erreur lors de l'installation de la base de données", ex);
	        }
	    }
	}

	

