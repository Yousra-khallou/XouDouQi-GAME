package com.XouDouQi.DAL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DbUtils {

    private String url = "jdbc:h2:~/XouDoQiGame/.data";
    private String user = "sa";
    private String pass = "";
    private String driverName = "org.h2.Driver";

    public static Connection con;

    private DbUtils() {

        //chargement du pilote
        try {
            Class.forName(driverName);
        } catch (Exception e) {
            throw new DbException("Erreur lors du chargement du pilote ", e);
        }
        //Connexion
        try {
            con = DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            e.printStackTrace();

            throw new DbException("Erreur lors de la connexion", e);
        }
    }

    public static Connection getConnection() {
        try {
            // Si pas de connexion OU si elle est fermée OU invalide => recréer
            if (con == null || con.isClosed() || !con.isValid(2)) {
                new DbUtils();
            }
        } catch (SQLException e) {
            throw new DbException("Erreur lors de la connexion", e);
        }
        return con;
    }

    public static void safelyResetAutoCommit() {
        try {
            if(con.getAutoCommit()==false) {
                con.setAutoCommit(true);
            }
        } catch (SQLException exAutoCommit) {
            try {
                con.close(); // tente de fermer la connexion
            } catch (SQLException exClose) {

                // Arrêt immédiat de l'application
                System.exit(-1);
            }


        }
    }


    public static void safelyCloseConnection() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (SQLException ex) {
            System.err.println("Erreur lors de la fermeture de la connexion.");
        }
    }


}


