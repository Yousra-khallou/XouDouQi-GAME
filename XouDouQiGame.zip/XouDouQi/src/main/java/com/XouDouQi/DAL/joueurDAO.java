package com.XouDouQi.DAL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.XouDouQi.BO.joueur;


public class joueurDAO {
	
	private Connection con = DbUtils.getConnection() ;
	
	public boolean CreateCompte(joueur pjoueur) throws DbException {
		int generatedId = -1;
		try {

			// instruction SQl avec un paramètre
			String InsertReq = "insert into joueur(username,total_victories,score) values(?,?,?)";
			// créer l'objet PreparedStatement
			PreparedStatement stm = con.prepareStatement(InsertReq, Statement.RETURN_GENERATED_KEYS);
			// définir la valeur du paramètre de la l'instruction SQL
			stm.setString(1, pjoueur.getUsername());
			stm.setInt(2, pjoueur.getTotal_victories());
			stm.setInt(3, pjoueur.getScore());

			
			// Executer l'instruction SQL
			stm.executeUpdate();

			ResultSet generatedKeys = stm.getGeneratedKeys();
			if (generatedKeys.next()) {
				generatedId = generatedKeys.getInt(1);
				pjoueur.setIdjoueur(generatedId);  
				return true;
			}
			
			return false;
		} catch (SQLException ex) {
			// remonter l'erreur
			throw new DbException(ex);
		}

	}
	
	public joueur connexionJoueur(int id, String nom) throws DbException {
		try {
			//preparation de la requete 
		PreparedStatement stm = con.prepareStatement("SELECT * FROM joueur WHERE idjoueur = ? and username= ?");
		stm.setInt(1, id);
		stm.setString(2, nom);
		
		ResultSet rs = stm.executeQuery();
		 //si un joueur existe avec id
	       if (rs.next()) {
	                joueur j = new joueur(rs.getInt("idjoueur"),rs.getString("username"));
	                j.setTotal_victories(rs.getInt("total_victories"));
	                j.setScore(rs.getInt("score"));
	                return j;
	            }
	        //aucun joueur trouvé
	        return null;
	    } catch (SQLException ex) {
	        throw new DbException(ex);
	    }
	}
	
	public joueur connexionJoueurById(int id) throws DbException {
		try {
			//preparation de la requete 
		PreparedStatement stm = con.prepareStatement("SELECT * FROM joueur WHERE idjoueur = ? ");
		stm.setInt(1, id);
		
		
		ResultSet rs = stm.executeQuery();
		 //si un joueur existe avec id
	       if (rs.next()) {
	                joueur j = new joueur(rs.getInt("idjoueur"),rs.getString("username"));
	                j.setTotal_victories(rs.getInt("total_victories"));
	                j.setScore(rs.getInt("score"));
	                return j;
	            }
	        //aucun joueur trouvé
	        return null;
	    } catch (SQLException ex) {
	        throw new DbException(ex);
	    }
	}
	public List<joueur> getAllJoueurs() throws DbException {
	    List<joueur> joueurs = new ArrayList<>();
	    String query = "SELECT * FROM joueur";

	    try (PreparedStatement stm = con.prepareStatement(query);
	         ResultSet rs = stm.executeQuery()) {

	        while (rs.next()) {
	            joueur j = new joueur(rs.getInt("idjoueur"), rs.getString("username"));
	            j.setTotal_victories(rs.getInt("total_victories"));
	            j.setScore(rs.getInt("score"));
	            joueurs.add(j);
	        }

	    } catch (SQLException ex) {
	        throw new DbException(ex);
	    }

	    return joueurs;
	}

  // methode pour mettre a jour le score dun joueur 
	public boolean updateScore(int idjoueur, int nouveauScore) throws DbException {
	    String sql = "UPDATE joueur SET score = ? WHERE idjoueur = ?";

	    try {
	    	
	        PreparedStatement stm = con.prepareStatement(sql);
	        stm.setInt(1, nouveauScore);
	        stm.setInt(2, idjoueur);
	        int rowsAffected = stm.executeUpdate();
	        return rowsAffected > 0;  // true si au moins un joueur a bien été mis à jour ,false sinon
	    } catch (SQLException ex) {
	        throw new DbException(ex);
	    }
	}
	// methode pour mettre a jour le nombre de victoire dun joueur 
	public boolean updateVictories(int idjoueur, int nouveauvict) throws DbException {
	    String sql = "UPDATE joueur SET total_victories = ? WHERE idjoueur = ?";

	    try {
	    	
	        PreparedStatement stm = con.prepareStatement(sql);
	        stm.setInt(1, nouveauvict);
	        stm.setInt(2, idjoueur);
	        int rowsAffected = stm.executeUpdate();
	        return rowsAffected > 0;  // true si au moins un joueur a bien été mis à jour ,false sinon
	    } catch (SQLException ex) {
	        throw new DbException(ex);
	    }
	}
	


	

}
