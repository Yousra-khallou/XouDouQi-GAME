package com.XouDouQi.GUI;

import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.XouDouQi.BLL.*;
import com.XouDouQi.BO.*;

import com.XouDouQi.DAL.*;


public class XouDouQiConsolApp {
	
	private static Logger logger = LoggerFactory.getLogger(XouDouQiConsolApp.class);
	public static void main(String[] args) {
		
		if(!databaseinstaller.checkIfDbExist()){
			logger.info("Installation de la base de données...");
			databaseinstaller.install();
			logger.info("Base de données installée correctement");
		}
		else{
			logger.info("la base de données existe déjà");
		}
		// création d'une instance de la classe qui gère la logique métier
		 GameManager gameManager = new GameManager();
		
				// Pour lire les données au clavier
				Scanner sc = new Scanner(System.in);
				while (true) {
					// afficher le menu
					Menu1.afficheMenuPrincipal();
					// lire le choix
					int choix = sc.nextInt();
					sc.nextLine(); // Consomme le saut de ligne restant

					// évite de sauter par nextInt
					try{
						switch (choix) {
							case 1:
								afficherRules.rules(sc);
								break;
							case 2: 
								joueur j1 = LogInJoueur.connexion(sc);  // joueur connecté
								try {
								    Thread.sleep(3000);  // Pause 3 secondes
								} catch (InterruptedException e) {
								    e.printStackTrace();
								}
								if(j1!=null) {
							    boolean enSession = true;
							    while (enSession) {
							       
							        gameManager.afficheMenuGame();
							        int choixGame = sc.nextInt();
							        sc.nextLine(); // éviter le saut de ligne

							        switch (choixGame) {
							            case 1:
							                gameManager.afficherInfosJoueur(j1);
							                try {
     										    Thread.sleep(5000);  // Pause 3 secondes
     										} catch (InterruptedException e) {
     										    e.printStackTrace();
     										}
     						               gameManager.afficheMenuGame();
							                break;
							            case 2:
     						                gameManager.afficherHistorique(j1);
     						               try {
     										    Thread.sleep(5000);  // Pause 3 secondes
     										} catch (InterruptedException e) {
     										    e.printStackTrace();
     										}
     						               gameManager.afficheMenuGame();
							                break;
							            case 3:
							                gameManager.lancerNouvellePartie(j1,sc,logger);
							                break;
							            case 4:
							            	 gameManager.afficherHistoriqueParties();
							            	 try {
	     										    Thread.sleep(5000);  // Pause 3 secondes
	     										} catch (InterruptedException e) {
	     										    e.printStackTrace();
	     										}
	     						              
								                break;
							            case 5:
							                System.out.println(" Retour au menu principal...");
							                enSession = false;
							                
							                break;
							            default:
							                System.out.println(" Choix invalide.");
							        }

							        System.out.println("\nAppuyez sur Entrée pour continuer...");
							        sc.nextLine(); // pause
							       
							    }
							    }
								
								break;
								
							case 3:
								LogInJoueur.creerCompte(sc);
								try {
								    Thread.sleep(4000);  // Pause 4 secondes
								} catch (InterruptedException e) {
								    e.printStackTrace();
								}
								afficherRules.clearConsole();
								
							    break;
			                case 4:
			                	for (int i = 0; i < 40; i++) {
			                        System.out.println();
			                    }
			                    System.out.println("                       👋 Merci d'avoir utilisé Jungle Animal Chess !");
	                    
			                    System.exit(0);
                            break;
			
    		                default:
    		                afficherRules.clearConsole();
		                    System.out.println(" Choix invalide. Réessayez.");
		                    Menu1.afficheMenuPrincipal();
		                 }
					}   catch (DbException ex){
						System.err.println(ex.getMessage());

						logger.error("Erreur à cause de :", ex);
					}
					
					catch (Exception ex){
						
						logger.error("Opération non effectuée à cause d'une erreur inconnue :", ex);

					}
					}
				}
	}
						
		
		
		
		
		
					
		
		
		
