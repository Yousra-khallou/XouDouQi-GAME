package com.XouDouQi.BO;

public class loup extends animal{
public loup(position P,joueur propriétaire) {
	super("loup",3,P, propriétaire);
}
	
}
