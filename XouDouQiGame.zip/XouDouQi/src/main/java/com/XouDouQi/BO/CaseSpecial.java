package com.XouDouQi.BO;

public class CaseSpecial {
  private char symbol;
  private joueur propriétaire;
  
  public CaseSpecial(char c, joueur j) {
	  this.symbol=c;
	  this.propriétaire=j;
  }
public char getSymbol() {
	return symbol;
}
public void setSymbol(char symbol) {
	this.symbol = symbol;
}
public joueur getProprietaire() {
	return propriétaire;
}
public void setPropriétaire(joueur propriétaire) {
	this.propriétaire = propriétaire;
}
}
