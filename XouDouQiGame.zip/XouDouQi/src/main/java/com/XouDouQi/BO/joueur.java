package com.XouDouQi.BO;

public class joueur {

	    private int idjoueur;
		private String username;
	    private int total_victories;
	    private int score;
	    
	public joueur(String username) {
		this.setUsername(username);
		
	}
	public joueur(int id,String username) {
		this.idjoueur=id;
		this.setUsername(username);
		
	} 
	public joueur(int id,String username,int score, int total) {
		this.idjoueur=id;
		this.setUsername(username);
		this.score=score;
		this.total_victories=total;
		
	}
	    
		public int getTotal_victories() {
			return total_victories;
		}
		public void setTotal_victories(int total_victories) {
			this.total_victories = total_victories;
		}
		public int getIdjoueur() {
			return idjoueur;
		}
		public void setIdjoueur(int idjoueur) {
			this.idjoueur = idjoueur;
		}
		public int getScore() {
			return score;
		}
		public void setScore(int score) {
			this.score = score;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		
		@Override
		public boolean equals(Object j) {
			if (this == j)
				return true;
			if(j==null)
			    return false;
			if(this.getClass()!=j.getClass())
				return false;
			joueur J= (joueur) j;
			return this.idjoueur==J.idjoueur && this.username.equalsIgnoreCase(J.username);
			
		}
}
