package com.XouDouQi.BO;

public class chien extends animal {
  public chien(position P,joueur propriétaire) {
	  super("chien",4,P,propriétaire);
  }
}
