package com.XouDouQi.BO;
import java.time.LocalDateTime;
public class GamePart {
	
	    private int idpartie;
	    private int idjoueur1;
	    private int idjoueur2;
	    private Integer idgagnant; // Peut être null (ex: en cas d'égalité ou partie en cours)
        private int score;
        private LocalDateTime datepartie;
			
		
	    // Constructeurs
        public GamePart() {}
        
	    public GamePart (int idpartie, int idjoueur1, int idjoueur2, Integer idgagnant, int score,LocalDateTime date) {
	        this.idpartie = idpartie;
	        this.idjoueur1 = idjoueur1;
	        this.idjoueur2 = idjoueur2;
	        this.idgagnant = idgagnant;
	        this.score =score;
	        this.setDatepartie(date);
	    }

	    public GamePart ( int idjoueur1, int idjoueur2, Integer idgagnant, int score,LocalDateTime date) {
	        this.idjoueur1 = idjoueur1;
	        this.idjoueur2 = idjoueur2;
	        this.idgagnant = idgagnant;
	        this.score =score;
	        this.setDatepartie(date);
	    }

	    public int getIdpartie() {
	        return idpartie;
	    }

	    public void setIdpartie(int idpartie) {
	        this.idpartie = idpartie;
	    }

	    public int getIdjoueur1() {
	        return idjoueur1;
	    }

	    public int getIdjoueur2() {
	        return idjoueur2;
	    }

	    public Integer getIdgagnant() {
	        return idgagnant;
	    }

	    public void setIdgagnant(Integer idgagnant) {
	        this.idgagnant = idgagnant;
	    }

		public int getScore() {
			return score;
		}

		public void setScore(int score) {
			this.score = score;
		}

		public LocalDateTime getDatepartie() {
			return datepartie;
		}

		public void setDatepartie(LocalDateTime datepartie) {
			this.datepartie = datepartie;
		}

	    
	   
	}

