package com.XouDouQi.BO;

public class Echiquier {
	//grille principal pour les animaux
	private animal[][] grille = new animal[9][7];
	//grille pour les cases specials : rivieres, sanctuaire, piéges
	private CaseSpecial[][] caseSpecial = new CaseSpecial[9][7];
	
	
 public Echiquier(joueur J1, joueur J2 ) {
	 //au debut toutes les cases sont des cases simples ' '
	 for(int i=0;i<9;i++) {	
		 for(int j=0;j<caseSpecial[i].length ;j++) {
			 caseSpecial[i][j]  = new CaseSpecial(' ',null);
		 }
	 }
	
	 //remplir les zones des deux rivieres
	
	 for (int i = 3; i < 6; i++) {
	     for (int j = 1; j < 3; j++) {
	         caseSpecial[i][j] = new CaseSpecial('≈', null); 
	     }
	     for (int j = 4; j < 6; j++) {
	         caseSpecial[i][j] = new CaseSpecial('≈', null); 
	     }
	 }
	 
	//remplir les zones pieges et sanctuaire propre  de joueur 1
	 caseSpecial[0][2]=new CaseSpecial('*',J1);
	 caseSpecial[0][4]=new CaseSpecial('*',J1);
	 caseSpecial[1][3]=new CaseSpecial('*',J1);
	 caseSpecial[0][3]=new CaseSpecial('S',J1);
	 
	//remplir les zones pieges et sanctuaire propre  de joueur 2
		 caseSpecial[8][2]=new CaseSpecial('*',J2);
		 caseSpecial[8][4]=new CaseSpecial('*',J2);
		 caseSpecial[7][3]=new CaseSpecial('*',J2);
		 caseSpecial[8][3]=new CaseSpecial('S',J2);
	 
		 
  //initiaiser la position des animaux de joueur 1
		 grille[0][0]= new tigre(new position(0, 0), J1);
		 grille[1][1]= new chat(new position(1, 1), J1);
		 grille[2][0]= new elephant(new position(2, 0), J1);
		 grille[2][2]= new loup(new position(2, 2), J1);
		 grille[2][4]= new panthere(new position(2, 4), J1);
		 grille[1][5]= new chien(new position(1, 5), J1);
		 grille[0][6]= new lion(new position(0, 6), J1);
		 grille[2][6]= new rat(new position(2, 6), J1);
		 
  //initiaiser la position des animaux de joueur 2
		 grille[8][6]= new tigre(new position(8, 6), J2);
		 grille[7][5]= new chat(new position(7, 5), J2);
		 grille[6][5]= new elephant(new position(6, 5), J2);
		 grille[6][4]= new loup(new position(6, 4), J2);
		 grille[6][3]= new panthere(new position(6, 3), J2);
		 grille[7][1]= new chien(new position(7, 1), J2);
		 grille[8][0]= new lion(new position(8, 0), J2);
		 grille[6][0]= new rat(new position(6, 0), J2);
	
 }
	 
 public boolean estRiviere(position p) {
	    return caseSpecial[p.getX()][p.getY()].getSymbol() == '≈';
	}
 
 public boolean estSanctuaireAdverse(position p, joueur j) {
	     
	    return caseSpecial[p.getX()][p.getY()].getSymbol() == 'S' && caseSpecial[p.getX()][p.getY()].getProprietaire() != null && caseSpecial[p.getX()][p.getY()].getProprietaire().getIdjoueur() != j.getIdjoueur() ;
	}
 
 public boolean estSanctuairePropre(position p, joueur j) {
     
	    return caseSpecial[p.getX()][p.getY()].getSymbol() == 'S' && caseSpecial[p.getX()][p.getY()].getProprietaire() != null && caseSpecial[p.getX()][p.getY()].getProprietaire().getIdjoueur() == j.getIdjoueur() ;
	}
public boolean estPiegeAdverse(position p, joueur j) {
    
    return caseSpecial[p.getX()][p.getY()].getSymbol() == '*' && caseSpecial[p.getX()][p.getY()].getProprietaire()!= null && caseSpecial[p.getX()][p.getY()].getProprietaire().getIdjoueur() != j.getIdjoueur();
}




public animal getAnimal(position p) {
    return grille[p.getX()][p.getY()];
}

public void setAnimal(position p, animal a) {
    grille[p.getX()][p.getY()] = a;
}

 //methode afficherEchiquier

public void afficheEchiquier(joueur j1, joueur j2) {
    // En-tête des colonnes
    System.out.println("              0    1    2    3    4    5    6");
    System.out.println("          ------------------------------------");

    for (int i = 0; i < 9; i++) {
        System.out.print("      " + i + "   "); // Affichage de l'indice de ligne

        for (int j = 0; j < 7; j++) {
            if (grille[i][j] != null) {
                animal a = grille[i][j];
                if (a.getPropriétaire().equals(j1)) {
                    switch (a.getNomEspece()) {
                        case "elephant": System.out.print("| 🐘 "); break;
                        case "lion":     System.out.print("| 🦁 "); break;
                        case "tigre":    System.out.print("| 🐯 "); break;
                        case "rat":      System.out.print("| 🐀 "); break;
                        case "loup":     System.out.print("| 🐺 "); break;
                        case "panthere": System.out.print("| 🐆 "); break;
                        case "chat":     System.out.print("| 🐱 "); break;
                        case "chien":    System.out.print("| 🐶 "); break;
                        default:         System.out.print("| ?  "); break;
                    }
                } else {
                    switch (a.getNomEspece()) {
                        case "elephant": System.out.print("|  E "); break;
                        case "lion":     System.out.print("|  L "); break;
                        case "tigre":    System.out.print("|  T "); break;
                        case "rat":      System.out.print("|  R "); break;
                        case "loup":     System.out.print("|  W "); break;
                        case "panthere": System.out.print("|  P "); break;
                        case "chat":     System.out.print("|  C "); break;
                        case "chien":    System.out.print("|  D "); break;
                        default:         System.out.print("|  ? "); break;
                    }
                }
            } else {
                char symbole = caseSpecial[i][j].getSymbol();
                switch (symbole) {
                    case '≈': System.out.print("| 🌊 "); break;
                    case '*': System.out.print("|  * "); break;
                    case 'S': System.out.print("| 🏰 "); break;
                    default:  System.out.print("|    "); break;
                }
            }
        }
        System.out.println("|");
        System.out.println("          ------------------------------------");
    }

    // Répéter les indices de colonnes en bas
    System.out.println("             0    1    2    3    4    5    6");
}


public boolean aDesPiecesActive(joueur J) {
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 7; j++) {
            animal a = grille[i][j];
            if (a != null && a.getPropriétaire().equals(J)) {
                return true;
            }
        }
    }
    return false;
}

   
}

	



