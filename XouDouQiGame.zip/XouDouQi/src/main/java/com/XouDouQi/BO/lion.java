package com.XouDouQi.BO;

public class lion extends animal {
	
   public lion(position P,joueur propriétaire) {
	   super("lion",7,P,propriétaire);
   }
   
   public void Move(Echiquier E, position p) {
       if (!PeutDeplacer(E, p)) return;

       animal aCapturer = E.getAnimal(p);

       if (aCapturer == null) {
           E.setAnimal(this.getP(), null);
           this.setP(p);
           E.setAnimal(p, this);
       } else if (!aCapturer.getPropriétaire().equals(this.getPropriétaire()) && PeutCapturer(E, aCapturer)) {
           E.setAnimal(this.getP(), null);
           this.setP(p);
           E.setAnimal(p, this);
           this.getPropriétaire().setScore(this.getPropriétaire().getScore() + 3);
       }
   }
   
   
   

   @Override
   
   public boolean PeutDeplacer(Echiquier E, position cible) {
       position actuelle = this.P;

       // Mouvement normal : une case adjacente, non rivière, non sanctuaire propre
       if (actuelle.EstCaseAdjacent(cible) && !E.estRiviere(cible) && !E.estSanctuairePropre(cible, this.getPropriétaire()))
           return true;

    // Mouvement spécial : saut horizontal par-dessus rivière
       if (actuelle.getX() == cible.getX()) {
           int y1 = actuelle.getY();
           int y2 = cible.getY();

           if (Math.abs(y1 - y2) > 1) {
               for (int y = Math.min(y1, y2) + 1; y < Math.max(y1, y2); y++) {
                   position pos = new position(actuelle.getX(), y);
                   if (!E.estRiviere(pos)) return false;

                   animal a = E.getAnimal(pos);
                   if (a instanceof rat) {
                       rat r = (rat) a;
                       if (r.isInwater()) return false;
                   }
               }
               return true;
           }
       }

       if (actuelle.getY() == cible.getY()) {
    	    int x1 = actuelle.getX();
    	    int x2 = cible.getX();

    	    if (Math.abs(x1 - x2) > 1) {
    	        for (int x = Math.min(x1, x2) + 1; x < Math.max(x1, x2); x++) {
    	            position pos = new position(x, actuelle.getY());
    	            if (!E.estRiviere(pos)) return false;

    	            animal a = E.getAnimal(pos);
    	            if (a instanceof rat) {
    	                rat r = (rat) a;
    	                if (r.isInwater()) return false;
    	            }
    	        }
    	        return true;
    	    }
    	}

       return false;
   }


   

}
