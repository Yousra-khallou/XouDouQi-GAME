package com.XouDouQi.BO;

public class rat extends animal {
    private boolean dans_eau;

    public rat(position P, joueur propriétaire) {
        super("rat", 1, P, propriétaire);
        this.dans_eau = false; 
    }

    @Override
    public void Move(Echiquier E, position p) {
    	//verifier case possible
        if (this.P.EstCaseAdjacent(p)) {
            if (!PeutDeplacer(E, p)) return;

            animal aCapturer = E.getAnimal(p);

            if (aCapturer == null) {
                // déplacement simple
                E.setAnimal(this.getP(), null);
                this.setP(p);
                E.setAnimal(p, this);

                // mise à jour de l'état "dans l'eau"
                this.dans_eau = E.estRiviere(p);

            } else if (!aCapturer.getPropriétaire().equals(this.getPropriétaire()) && PeutCapturer(E, aCapturer)) {

                E.setAnimal(this.getP(), null);
                this.setP(p);
                E.setAnimal(p, this);
                this.dans_eau = E.estRiviere(p);
                this.getPropriétaire().setScore(this.getPropriétaire().getScore() + 3);
            }
        }
    }

    @Override
    public boolean PeutCapturer(Echiquier E, animal aCapturer) {
        if (aCapturer.getPropriétaire().equals(this.getPropriétaire())) return false;

        // Cas particulier : rat ne peut pas capturer un rat s’ils  sont tous les deux dans l’eau ou sur terre 
        if (aCapturer instanceof rat) {
            rat r = (rat) aCapturer;
            if (this.isInwater() != r.isInwater()) 
            	return false;
        }


        // Peut capturer un éléphant (règle spéciale)
        if ( aCapturer.getNomEspece().equals("elephant")) return !this.dans_eau;

        // Si la cible est dans un piège adverse
        if (E.estPiegeAdverse(aCapturer.getP(), aCapturer.getPropriétaire())) return true;

        return this.getForce() >= aCapturer.getForce();
    }

    @Override
    public boolean PeutDeplacer(Echiquier E, position p) {
        // on interd le sanctuaire propre seulement
        return !E.estSanctuairePropre(p, this.getPropriétaire());
    }

    public boolean isInwater() {
        return dans_eau;
    }

    public void setInwater(boolean inwater) {
        this.dans_eau = inwater;
    }

    
}
