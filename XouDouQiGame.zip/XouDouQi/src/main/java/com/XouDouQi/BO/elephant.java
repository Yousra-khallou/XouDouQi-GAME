package com.XouDouQi.BO;

public class elephant extends animal {

	public elephant(position P,joueur propriétaire) {
		super("elephant",8,P, propriétaire);
	}
	
}
