package com.XouDouQi.BO;

public class chat extends animal {
public chat(position P,joueur propriétaire) {
	super("chat",2,P, propriétaire);
}



}
