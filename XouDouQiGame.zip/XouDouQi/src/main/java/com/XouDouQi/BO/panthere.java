package com.XouDouQi.BO;

public class panthere extends animal{

	public panthere(position P,joueur propriétaire) {
		super("panthere", 5 ,P,propriétaire);
		// TODO Auto-generated constructor stub
	}

	
}
