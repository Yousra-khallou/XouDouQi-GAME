package com.XouDouQi.BO;

public abstract class animal {
	protected String NomEspece;
	protected int force;
	protected position P;
	protected joueur propriétaire;
	
	public animal(String nom, int force ,position P,joueur propriétaire) {
		this.NomEspece=nom;
		this.setForce(force);
		this.propriétaire=propriétaire;
		this.setP(P);			
	}
	
	//methode assure le movement du piece en fonction de la position voulue
	public void Move(Echiquier E, position p) {
		// Vérifie si la position est adjacente
		
	    if (this.P.EstCaseAdjacent(p)) { // case valide pour deplacer la piece 
	    	animal aCapturer  = E.getAnimal(p);
	        
	        // Si la case est vide(pas de piece )
	        if (aCapturer == null) {
	        	
	            // Vérifie si le dépacapturerlacement est possible
	            if (PeutDeplacer(E, p)) {
	                // Déplacement
	                E.setAnimal(this.getP(), null); // enlever l’animal de la position initial
	                this.setP(p); // mettre à jour la position
	                E.setAnimal(p, this); // placer à la nouvelle position
	               
	            }
	        }
	        
	        
	        else if (!aCapturer.getPropriétaire().equals(this.getPropriétaire()) && PeutCapturer(E,aCapturer)) {
	            if (PeutDeplacer(E, p)) {
	                E.setAnimal(this.getP(), null);
	                this.setP(p);
	                E.setAnimal(p, this);
	                this.propriétaire.setScore( this.propriétaire.getScore()+3); //ajouter 3points au score du joueur 
	            }
	        }
	    }
	}
	
	public boolean PeutCapturer(Echiquier E,animal aCapturer) {
		// Ne peut pas capturer ses frères 
	    if (aCapturer.getPropriétaire().equals(this.getPropriétaire())) return false;

	    // Cas spécial : rat dans l’eau ,non capturable
	    if (aCapturer instanceof rat) {
	        rat r = (rat) aCapturer;
	        if (r.isInwater()) return false;
	    
	}
	    //piece a nimporte quelle force dans le piege, donc capturable
	    if(E.estPiegeAdverse(aCapturer.getP(), aCapturer.getPropriétaire()))
	    	return true;
	    
	    // Peut capturer si la force est inferieure ou egal 
	    return this.getForce() >= aCapturer.getForce();

	}
	
	public boolean PeutDeplacer(Echiquier E, position p) {
		 // La piece en general ne peut pas aller dans la rivière, ni dans son propre sanctuaire
	    return !E.estRiviere(p) && !E.estSanctuairePropre(p, this.getPropriétaire());
	}
	

	public joueur getPropriétaire() {
		return propriétaire;
	}
	public String getNomEspece() {
		return NomEspece;
	}
	public void setNomEspece(String nomEspece) {
		NomEspece = nomEspece;
	}

	public position getP() {
		return P;
	}

	public void setP(position p) {
		P = p;
	}

	public int getForce() {
		return force;
	}

	public void setForce(int force) {
		this.force = force;
	}
	
	
	


}
